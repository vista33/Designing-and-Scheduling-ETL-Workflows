from airflow import DAG
from airflow.decorators import task

with DAG(dag_id='dag_xcom_with_decorator') as dag:
   @task
   def task_a():
       return "Data from Task A"

   @task
   def task_b(data):
       print(f"Received XCom value: {data}")

   task_b(task_a())
