from airflow import DAG
from airflow.operators.empty import EmptyOperator

dag = DAG(dag_id="dag_with_variable")

task_1 = EmptyOperator(
   task_id = "task_ke_1",
   dag     = dag,
)

task_2 = EmptyOperator(
   task_id = "task_ke_2",
   dag     = dag,
)

task_3 = EmptyOperator(
   task_id = "task_ke_3",
   dag     = dag,
)

task_4 = EmptyOperator(
   task_id = "task_ke_4",
   dag     = dag,
)

task_5 = EmptyOperator(
   task_id = "task_ke_5",
   dag     = dag,
)

task_1 >> [task_2,task_3] >> task_4 >> task_5

# >> sequence
# [] paralel