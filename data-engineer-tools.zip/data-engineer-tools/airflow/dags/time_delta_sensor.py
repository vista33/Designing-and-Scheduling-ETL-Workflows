from airflow import DAG
from airflow.sensors.time_delta import TimeDeltaSensor
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

with DAG(
   dag_id='example_timedelta_sensor_10s',
   start_date=datetime(2024, 8, 1),
   schedule_interval='@daily',
   catchup=False
) as dag:

   wait_10_seconds = TimeDeltaSensor(
       task_id='wait_10_seconds',
       delta=timedelta(seconds=10)
   )

   task_after_wait = BashOperator(
       task_id='task_after_wait',
       bash_command='echo "Waited 10 seconds, now running task."'
   )

   wait_10_seconds >> task_after_wait
