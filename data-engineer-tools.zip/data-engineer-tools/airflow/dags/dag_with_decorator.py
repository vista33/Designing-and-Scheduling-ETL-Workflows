from airflow.decorators import dag
from airflow.operators.empty import EmptyOperator

@dag()
def dag_with_decorator():
   task_1 = EmptyOperator(
       task_id = "task_ke_1"
   )

   task_2 = EmptyOperator(
       task_id = "task_ke_2"
   )

   task_3 = EmptyOperator(
       task_id = "task_ke_3"
   )

   task_1 >> [task_2,task_3]

dag_with_decorator()
