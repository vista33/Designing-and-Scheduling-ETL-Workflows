from airflow import DAG
from airflow.sensors.time_sensor import TimeSensor
from airflow.operators.bash import BashOperator
from datetime import datetime, time

with DAG(
   dag_id='example_time_sensor',
   start_date=datetime(2024, 8, 1),
   schedule_interval='@daily',
   catchup=False
) as dag:

   wait_until_morning = TimeSensor(
       task_id='wait_until_3.22am',
       target_time=time(3, 22)
   )

   morning_task = BashOperator(
       task_id='morning_task',
       bash_command='echo "Good morning! Task is running."'
   )

   wait_until_morning >> morning_task
