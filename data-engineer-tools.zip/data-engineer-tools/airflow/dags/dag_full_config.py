from airflow.decorators import dag
from airflow.operators.empty import EmptyOperator
from datetime import datetime, timedelta

@dag(
   dag_id            = "dag_full_config",
   description       = "ini adalah deskripsi dag",
   schedule_interval = "* * * * *", #minute,hour, day, week, month
   start_date        = datetime(2024, 7, 1),
   catchup           = False,
   tags              = ["tag dag"],
   default_args      = {
       "owner": "dibimbing students",
       "retries": 3,
       "retry_delay": timedelta(minutes=5),
   },
   owner_links = {
       "dibimbing": "https://dibimbing.id/",
       "students"    : "mailto:students@dibimbing.id",
   }
)
def main():
   task_1 = EmptyOperator(
       task_id = "task_ke_1"
   )

   task_1

main()
