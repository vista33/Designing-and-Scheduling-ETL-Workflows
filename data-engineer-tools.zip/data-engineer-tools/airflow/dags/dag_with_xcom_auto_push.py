from airflow import DAG
from airflow.operators.python import PythonOperator

def return_value():
   return "Auto pushed to XCom!"

with DAG(dag_id='dag_with_xcom_auto_push') as dag:

   push_auto = PythonOperator(
       task_id='push_auto',
       python_callable=return_value
   )

   def read_value(**context):
       val = context['task_instance'].xcom_pull(task_ids='push_auto')
       print(f"Pulled value: {val}")

   pull_manual = PythonOperator(
       task_id='pull_manual',
       python_callable=read_value,
       provide_context=True
   )

   push_auto >> pull_manual
