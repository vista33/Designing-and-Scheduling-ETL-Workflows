from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.mysql.hooks.mysql import MySqlHook
from airflow.utils.dates import days_ago
import logging

logger = logging.getLogger(__name__)

default_args = {
   'owner': 'data-engineering-team',
   'depends_on_past': False,
   'start_date': days_ago(1),
   'email_on_failure': False,
   'email_on_retry': False,
   'retries': 1,
   'retry_delay': timedelta(minutes=2),
}

dag = DAG(
   'test_database_connections',
   default_args=default_args,
   description='Test PostgreSQL and MySQL database connections',
   schedule_interval=None,  # Manual trigger only
   catchup=False,
   tags=['test', 'connections', 'database'],
)

def test_postgres_connection(**context):
   """Test PostgreSQL connection"""
   try:
       logger.info("=" * 80)
       logger.info("🔍 Testing PostgreSQL Source Connection...")
       logger.info("=" * 80)
      
       postgres_hook = PostgresHook(postgres_conn_id='postgres_source')
       connection = postgres_hook.get_conn()
       cursor = connection.cursor()
      
       # Test query
       cursor.execute("SELECT version();")
       version = cursor.fetchone()[0]
      
       logger.info(f"✅ PostgreSQL connection successful!\n   Version: {version}")
      
       # Test source database
       cursor.execute("SELECT COUNT(*) FROM raw_data.customers;")
       customer_count = cursor.fetchone()[0]
      
       logger.info(f"📊 Found {customer_count} customers in source database")
      
       cursor.close()
       connection.close()
      
       logger.info("=" * 80)
       return {"status": "success", "version": version, "customer_count": customer_count}
      
   except Exception as e:
       logger.error(f"❌ PostgreSQL connection failed: {str(e)}")
       raise

def test_mysql_connection(**context):
   """Test MySQL connection"""
   try:
       logger.info("=" * 80)
       logger.info("🔍 Testing MySQL Target Connection...")
       logger.info("=" * 80)
      
       mysql_hook = MySqlHook(mysql_conn_id='mysql_target')
       connection = mysql_hook.get_conn()
       cursor = connection.cursor()
      
       # Test query
       cursor.execute("SELECT VERSION();")
       version = cursor.fetchone()[0]
      
       logger.info(f"✅ MySQL connection successful!\n   Version: {version}")
      
       # Test target database
       cursor.execute("SELECT COUNT(*) FROM dim_customers;")
       customer_count = cursor.fetchone()[0]
      
       logger.info(f"📊 Found {customer_count} customers in target database")
      
       cursor.close()
       connection.close()
      
       logger.info("=" * 80)
       return {"status": "success", "version": version, "customer_count": customer_count}
      
   except Exception as e:
       logger.error(f"❌ MySQL connection failed: {str(e)}")
       raise

def validate_schema_compatibility(**context):
   """Validate that source and target schemas are compatible"""
   try:
       logger.info("=" * 80)
       logger.info("🔍 Validating Schema Compatibility...")
       logger.info("=" * 80)
      
       # Get results from previous tasks
       postgres_result = context['task_instance'].xcom_pull(task_ids='test_postgres')
       mysql_result = context['task_instance'].xcom_pull(task_ids='test_mysql')
      
       logger.info("✅ Schema compatibility check passed!")
       logger.info(f"📊 PostgreSQL Results: {postgres_result}")
       logger.info(f"📊 MySQL Results: {mysql_result}")
      
       logger.info("=" * 80)
       return {"status": "compatible", "postgres": postgres_result, "mysql": mysql_result}
      
   except Exception as e:
       logger.error(f"❌ Schema compatibility check failed: {str(e)}")
       raise
# Define tasks
test_postgres = PythonOperator(
   task_id='test_postgres',
   python_callable=test_postgres_connection,
   dag=dag,
)
test_mysql = PythonOperator(
   task_id='test_mysql',
   python_callable=test_mysql_connection,
   dag=dag,
)
validate_schema = PythonOperator(
   task_id='validate_schema_compatibility',
   python_callable=validate_schema_compatibility,
   dag=dag,
)
# Set dependencies
[test_postgres, test_mysql] >> validate_schema
