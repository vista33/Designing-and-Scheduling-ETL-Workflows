from datetime import timedelta
import re
import logging

from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.mysql.hooks.mysql import MySqlHook
from airflow.operators.python import PythonOperator

#1. Define the default args
default_args = {
    'owner': 'data-engineering-team',
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

#2. Extraction function
#2.1. Extract customers data from postgres
def extract_customers_from_postgres(**context):
    """Extract customer data from PostgreSQL and push to XCom"""
    try:
        hook = PostgresHook(postgres_conn_id='connection_testing') #name my connection in apache airflow
        sql_query = """
            SELECT *
            FROM raw_data.customers
            WHERE updated_at >= CURRENT_DATE - INTERVAL '1 day';
        """
        conn = hook.get_conn()
        cursor = conn.cursor()
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        customers = [dict(zip(columns, row)) for row in rows]
        context['ti'].xcom_push(key='customers_data', value=customers)
        logging.info(f"Extracted {len(customers)} customer records.")
    except Exception as e:
        logging.error(f"Error extracting customers: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

#2.2. Extract products from postgres
def extract_products_from_postgres(**context):
    """Extract product data from PostgreSQL and push to XCom"""
    try:
        hook = PostgresHook(postgres_conn_id='connection_testing')
        sql_query = """
            SELECT p.*, s.supplier_name
            FROM raw_data.products p
            LEFT JOIN raw_data.suppliers s
            USING (supplier_id)
            WHERE p.updated_at >= CURRENT_DATE - INTERVAL '1 day';
        """
        conn = hook.get_conn()
        cursor = conn.cursor()
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        products = [dict(zip(columns, row)) for row in rows]
        context['ti'].xcom_push(key='products_data', value=products)
        logging.info(f"Extracted {len(products)} product records.")
    except Exception as e:
        logging.error(f"Error extracting products: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

#2.3. Extract orders from postgres
def extract_orders_from_postgres(**context):
    """Extract order data from PostgreSQL and push to XCom"""
    try:
        hook = PostgresHook(postgres_conn_id='connection_testing')
        sql_query = """
            SELECT *
            FROM raw_data.orders
            WHERE updated_at >= CURRENT_DATE - INTERVAL '1 day';
        """
        conn = hook.get_conn()
        cursor = conn.cursor()
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        orders = [dict(zip(columns, row)) for row in rows]
        context['ti'].xcom_push(key='orders_data', value=orders)
        logging.info(f"Extracted {len(orders)} order records.")
    except Exception as e:
        logging.error(f"Error extracting orders: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

#3. Transform and Load Functions
#3.1. Transform and Load Customers
def transform_and_load_customers(**context):
    """Transform customer data and UPSERT into MySQL dim_customers"""
    try:
        customers = context['ti'].xcom_pull(task_ids='extract_customers', key='customers_data')
        for customer in customers:
            # Transform phone: remove non-digit, format as (XXX) XXX-XXXX
            phone_digits = re.sub(r'\D', '', str(customer.get('phone', '')))
            if len(phone_digits) == 10:
                customer['phone'] = f"({phone_digits[:3]}) {phone_digits[3:6]}-{phone_digits[6:]}"
            else:
                customer['phone'] = phone_digits
            # Uppercase state
            if 'state' in customer and customer['state']:
                customer['state'] = customer['state'].upper()
        # Load into MySQL
        mysql = MySqlHook(mysql_conn_id='mysql_target') # name my connection in apache airflow
        for c in customers:
            columns = ', '.join(c.keys())
            placeholders = ', '.join(['%s'] * len(c))
            update_clause = ', '.join([f"{k}=VALUES({k})" for k in c.keys()])
            sql = f"INSERT INTO dim_customers ({columns}) VALUES ({placeholders}) ON DUPLICATE KEY UPDATE {update_clause}"
            mysql.run(sql, parameters=list(c.values()))
        logging.info(f"Transformed & loaded {len(customers)} customers into dim_customers.")
    except Exception as e:
        logging.error(f"Error transforming/loading customers: {e}")
        raise

#3.2. Transforms and Load Products
def transform_and_load_products(**context):
    """Transform products, create missing columns, insert suppliers first, then UPSERT into dim_products"""
    try:
        products = context['ti'].xcom_pull(task_ids='extract_products', key='products_data')
        if not products:
            logging.warning("No product data found in XCom.")
            return

        mysql = MySqlHook(mysql_conn_id='mysql_target')
        conn = mysql.get_conn()
        cursor = conn.cursor()


        # Step 0: Add missing columns supplier name and margin

        cursor.execute("SHOW COLUMNS FROM dim_products LIKE 'supplier_name'")
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE dim_products ADD COLUMN supplier_name VARCHAR(255)")
            logging.info("Added missing column supplier_name to dim_products")

        # Check margin
        cursor.execute("SHOW COLUMNS FROM dim_products LIKE 'margin'")
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE dim_products ADD COLUMN margin DECIMAL(10,2)")
            logging.info("Added missing column margin to dim_products")

        conn.commit()  # Commit schema changes
        cursor.close()
        conn.close()


        # Step 1: Insert suppliers first (to satisfy FK)
        suppliers = {p['supplier_id']: p['supplier_name'] 
                     for p in products if p.get('supplier_id') and p.get('supplier_name')}
        for sid, name in suppliers.items():
            sql_sup = """
            INSERT INTO dim_suppliers (supplier_id, supplier_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE supplier_name=VALUES(supplier_name)
            """
            mysql.run(sql_sup, parameters=[sid, name])

        # Step 2: Transform products
        for p in products:
            # Margin
            try:
                price = float(p.get('price', 0))
                cost = float(p.get('cost', 0))
                p['margin'] = round(((price - cost)/price) * 100, 2) if price else 0
            except Exception:
                p['margin'] = 0

            # Category title case
            if 'category' in p and p['category']:
                p['category'] = p['category'].title()

        # Step 3: UPSERT products
        mysql_columns = ['product_id','product_name','category','price','cost','supplier_id','supplier_name','margin']
        for p in products:
            p = {k:v for k,v in p.items() if k in mysql_columns}
            columns = ', '.join(p.keys())
            placeholders = ', '.join(['%s'] * len(p))
            update_clause = ', '.join([f"{k}=VALUES({k})" for k in p.keys()])
            sql = f"INSERT INTO dim_products ({columns}) VALUES ({placeholders}) ON DUPLICATE KEY UPDATE {update_clause}"
            mysql.run(sql, parameters=list(p.values()))

        logging.info(f"Transformed & loaded {len(products)} products into dim_products (supplier_name & margin handled).")

    except Exception as e:
        logging.error(f"Error transforming/loading products: {e}")
        raise


#3.3. Transform and Load Orders
def transform_and_load_orders(**context):
    """Transform order data and UPSERT into MySQL fact_orders"""
    try:
        orders = context['ti'].xcom_pull(task_ids='extract_orders', key='orders_data')
        for o in orders:
            # Status lowercase
            if 'status' in o and o['status']:
                o['status'] = o['status'].lower()
            # Validate total_amount positive
            try:
                total = float(o.get('total_amount', 0))
                if total < 0:
                    logging.warning(f"Order {o.get('order_id')} has negative total_amount, setting to 0.")
                    o['total_amount'] = 0
                else:
                    o['total_amount'] = total
            except Exception:
                o['total_amount'] = 0

        mysql = MySqlHook(mysql_conn_id='mysql_target')
        for o in orders:
            columns = ', '.join(o.keys())
            placeholders = ', '.join(['%s'] * len(o))
            update_clause = ', '.join([f"{k}=VALUES({k})" for k in o.keys()])
            sql = f"INSERT INTO fact_orders ({columns}) VALUES ({placeholders}) ON DUPLICATE KEY UPDATE {update_clause}"
            mysql.run(sql, parameters=list(o.values()))
        logging.info(f"Transformed & loaded {len(orders)} orders into fact_orders.")
    except Exception as e:
        logging.error(f"Error transforming/loading orders: {e}")
        raise

#4. DAG Definition
with DAG(
    dag_id='postgres_to_mysql_etl',
    default_args=default_args,
    description='Full ETL pipeline: Extract → Transform → Load PostgreSQL → MySQL',
    schedule_interval=timedelta(hours=6),
    start_date=days_ago(1),
    catchup=False,
    tags=['etl', 'postgresql', 'mysql', 'data-pipeline'],
) as dag:

    # Extract tasks
    extract_customers_task = PythonOperator(
        task_id='extract_customers',
        python_callable=extract_customers_from_postgres,
        provide_context=True,
    )

    extract_products_task = PythonOperator(
        task_id='extract_products',
        python_callable=extract_products_from_postgres,
        provide_context=True,
    )

    extract_orders_task = PythonOperator(
        task_id='extract_orders',
        python_callable=extract_orders_from_postgres,
        provide_context=True,
    )

    # Transform & Load tasks
    transform_load_customers_task = PythonOperator(
        task_id='transform_load_customers',
        python_callable=transform_and_load_customers,
        provide_context=True,
    )

    transform_load_products_task = PythonOperator(
        task_id='transform_load_products',
        python_callable=transform_and_load_products,
        provide_context=True,
    )

    transform_load_orders_task = PythonOperator(
        task_id='transform_load_orders',
        python_callable=transform_and_load_orders,
        provide_context=True,
    )

#5. Dag Dependencies
    extract_customers_task >> transform_load_customers_task
    extract_products_task >> transform_load_products_task
    extract_orders_task >> transform_load_orders_task

    

